<?php
const Phone = [
    'price' => 10,
    'currency' => 'USD',
    'itemName' => 'Mobile Phone',
    'itemDescription' => 'Mobile Phone example item',
    'itemIcon' => 'Phone.png',
];