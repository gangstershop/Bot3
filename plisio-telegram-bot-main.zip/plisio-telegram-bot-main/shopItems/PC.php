<?php
const PC = [
    'price' => 500,
    'currency' => 'USD',
    'itemName' => 'PC',
    'itemDescription' => 'PC example item',
    'itemIcon' => 'PC.png',
];