<?php
const Notebook = [
    'price' => 100,
    'currency' => 'USD',
    'itemName' => 'Notebook',
    'itemDescription' => 'Notebook example item',
    'itemIcon' => 'Notebook.png',
];