<?php
const API_KEY = 'plisio_secret_key';